package test1;

public class Clinit2 {
    public int i = 123;
    public static int j;

    public int run() { return j; }
}
