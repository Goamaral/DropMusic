package test4;

public class DeclMethodsList {
    public void foo() {}
    int foo(int i) { return i; }
    public void bar() {}
}
