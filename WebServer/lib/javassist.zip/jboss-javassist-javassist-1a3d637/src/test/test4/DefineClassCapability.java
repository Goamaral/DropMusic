/*
 * This is used as a capability for running CtClass#toClass().
 */
package test4;

public class DefineClassCapability {
}
